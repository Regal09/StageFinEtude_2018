package com.a1011011gmail.youssef.cibelscan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Menu extends AppCompatActivity {

    TextView name;
    ImageView add, update, info, delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        add = (ImageView) findViewById(R.id.imageView2);
        update = (ImageView) findViewById(R.id.imageView3);
        info = (ImageView) findViewById(R.id.imageView4);
        delete = (ImageView)findViewById(R.id.imageView5);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(add.isPressed())
                {
                    Intent i = new Intent(Menu.this, Insertion.class);
                    startActivity(i);
                }
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(update.isPressed())
                {
                    Intent i = new Intent(Menu.this, Updateplace.class);
                    startActivity(i);
                }
            }
        });

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(info.isPressed())
                {
                    Intent i = new Intent(Menu.this, Information.class);
                    startActivity(i);
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(delete.isPressed())
                {
                    Intent i = new Intent(Menu.this, Deletec.class);
                    startActivity(i);
                }
            }
        });

        name = (TextView) findViewById(R.id.emailforward);
        Bundle bundle = getIntent().getExtras();
        name.setText(bundle.getString("name"));
    }
}
