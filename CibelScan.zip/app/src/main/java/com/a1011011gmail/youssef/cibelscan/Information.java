package com.a1011011gmail.youssef.cibelscan;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpResponse;
import com.android.volley.toolbox.StringRequest;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Information extends AppCompatActivity {

    InputStream is=null;
    String result=null;
    String line=null;
    HttpURLConnection urlConnection = null;
    Spinner spinner1,spinner2;

    String text, text2, text3;
    String [] city, city2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        final  EditText et = (EditText) findViewById(R.id.cd);
        final EditText et2 = (EditText) findViewById(R.id.cd2);
        Button b = (Button) findViewById(R.id.search);
        Button b2 = (Button) findViewById(R.id.search2);
        Button b3 = (Button) findViewById(R.id.sr);
        spinner1 = (Spinner) findViewById(R.id.spn);
        spinner2= (Spinner) findViewById(R.id.spn2);

        b.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                text = et.getText().toString().trim(); //Here i am storing the entered text in the string format in text variable

                ContentValues values = new ContentValues();
                values.put("1", text);  // This will append the entered text in the url for filter purpose

                try {

                    URL url = new URL("http://doctime.lyo.ma/CibelScan/search.php?string1=" + text);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("POST");
                    urlConnection.connect();
                    is = urlConnection.getInputStream();
                } catch (Exception e) {
                    Log.e("Fail 1", e.toString());
                }

                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    is.close();
                    result = sb.toString();
                } catch (Exception e) {
                    Log.e("Fail 2", e.toString());
                }


                try {
                    JSONArray JA = new JSONArray(result);
                    JSONObject json = null;

                    city = new String[JA.length()];


                    for (int i = 0; i < JA.length(); i++) {
                        json = JA.getJSONObject(i);
                        city[i] = json.getString("numarticle");

                    }

                    Log.e("récupéré1", result);
                    Toast.makeText(getApplicationContext(), "Data Loaded", Toast.LENGTH_LONG).show();

                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(Information.this, android.R.layout.simple_spinner_item, city);
                    spinner1.setAdapter(adapter);

                    spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                    {
                        public void onItemSelected(AdapterView<?> arg0, View arg1,
                                                   int arg2, long arg3)
                        {

                            text2 = spinner1.getSelectedItem().toString().trim();

                        }
                        public void onNothingSelected(AdapterView<?> arg0)
                        {
                            // TODO Auto-generated method stub
                        }
                    });







                } catch (Exception e) {

                    Log.e("Fail 3", e.toString());


                }

            }

        });

        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                ContentValues values2 = new ContentValues();
                values2.put("1", text2);  // This will append the entered text in the url for filter purpose


                try {

                    URL url = new URL("http://doctime.lyo.ma/CibelScan/search2.php?string1=" + text2 + "&string2="+ text);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("POST");
                    urlConnection.connect();
                    is = urlConnection.getInputStream();
                } catch (Exception e) {
                    Log.e("Fail 4", e.toString());
                }


                try {
                    BufferedReader reader2 = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
                    StringBuilder sb2 = new StringBuilder();
                    while ((line = reader2.readLine()) != null) {
                        sb2.append(line + "\n");
                    }
                    is.close();
                    result = sb2.toString();
                } catch (Exception e) {
                    Log.e("Fail 5", e.toString());
                }

                Log.e("récupéré1.1", result);
                try {
                    JSONArray JA = new JSONArray(result);
                    JSONObject json = null;

                    city2 = new String[JA.length()];


                    for (int i = 0; i < JA.length(); i++) {
                        json = JA.getJSONObject(i);
                        city2[i] = json.getString("numlot");

                    }
                    Log.e("récupéré2", result);
                    Toast.makeText(getApplicationContext(), "Data Loaded 2", Toast.LENGTH_LONG).show();

                    ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(Information.this, android.R.layout.simple_spinner_item, city2);
                    spinner2.setAdapter(adapter2);

                    spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                    {
                        public void onItemSelected(AdapterView<?> arg0, View arg1,
                                                   int arg2, long arg3)
                        {

                            text3 = spinner2.getSelectedItem().toString().trim();

                        }
                        public void onNothingSelected(AdapterView<?> arg0)
                        {
                            // TODO Auto-generated method stub
                        }
                    });







                } catch (Exception e) {

                    Log.e("Fail 6", e.toString());


                }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                try {

                    URL url = new URL("http://doctime.lyo.ma/CibelScan/getemp2.php?string1=" + text2 + "&string2="+text + "&string3="+text3);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("POST");
                    urlConnection.connect();
                    is = urlConnection.getInputStream();
                } catch (Exception e) {
                    Log.e("Fail 7", e.toString());
                }

                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    is.close();
                    result = sb.toString();


                } catch (Exception e) {
                    Log.e("Fail 8", e.toString());
                }


                try {
                    JSONArray JA = new JSONArray(result);
                    JSONObject json = null;


                    city = new String[JA.length()];


                    for (int i = 0; i < JA.length(); i++) {
                        json = JA.getJSONObject(i);
                        city[i] = json.getString("emplacement");

                    }
//                    Toast.makeText(getApplicationContext(), "Data Loaded", Toast.LENGTH_LONG).show();




                    String s = result;
                    String[] arr = s.split("\"");

                    et2.setText(arr[3]);
                } catch (Exception e) {

                    Log.e("Fail 9", e.toString());


                }


            }

        });
        }


    }