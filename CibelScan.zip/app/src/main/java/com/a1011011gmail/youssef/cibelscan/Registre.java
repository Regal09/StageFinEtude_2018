package com.a1011011gmail.youssef.cibelscan;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Registre extends AppCompatActivity {

    private static final String REGISTER_URL = "http://doctime.lyo.ma/CibelScan/volleyRegistre.php";

    public static final String KEY_NAME = "name";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_REPASSWORD = "repassword";

    private EditText editname;
    private EditText editpassword;
    private EditText editrepassword;

    private Button registrebutton;

    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registre);

        editname = (EditText)findViewById(R.id.editemail);
        editpassword = (EditText) findViewById(R.id.editpassword);
        editrepassword = (EditText) findViewById(R.id.editrepassword);

        builder = new AlertDialog.Builder(Registre.this);

        registrebutton = (Button) findViewById(R.id.registrebutton);


        registrebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = editname.getText().toString().trim();
                final String password = editpassword.getText().toString().trim();
                final String repassword = editrepassword.getText().toString().trim();

                if(name.equals("") || password.equals("") || repassword.equals(""))
                {
                    builder.setTitle("There is a problem !!!");
                    builder.setMessage("Please fill all the fields ...");
                    displayAlert("input_error");
                }

                else{
                    if (!(password.equals(repassword))){
                        builder.setTitle("There is a problem !!!");
                        builder.setMessage("Your password are not matching ...");
                        displayAlert("input_error");
                    }
                    else
                    {
                        StringRequest stringRequest = new StringRequest(Request.Method.POST,REGISTER_URL,
                                new Response.Listener<String>() {

                                    @Override
                                    public void onResponse(String response) {

                                        try {
                                            JSONArray jsonArray = new JSONArray(response);
                                            JSONObject jsonObject = jsonArray.getJSONObject(0);
                                            String code = jsonObject.getString("code");
                                            String message = jsonObject.getString("message");

                                            builder.setTitle("Server response ...");
                                            builder.setMessage(message);
                                            displayAlert(code);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }


                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(Registre.this,error.toString(), Toast.LENGTH_LONG).show();
                            }
                        }){
                            @Override
                            protected Map<String, String> getParams(){
                                Map<String,String> params = new HashMap<String, String>();
                                params.put(KEY_NAME,name);
                                params.put(KEY_PASSWORD,password);
                                params.put(KEY_REPASSWORD,repassword);
                                return params;
                            }
                        };

                        MySingleton.getmInstance(Registre.this).addToRequestque(stringRequest);
                    }

                }
            }
        });

    }

    public void displayAlert(final String code){
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (code.equals("input_error")){
                    editpassword.setText("");
                    editrepassword.setText("");
                }
                else if (code.equals("register_Succes")){
                    finish();
                }
                else if (code.equals("register_Failed")){
                    editname.setText("");
                    editpassword.setText("");
                    editrepassword.setText("");
                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

}
