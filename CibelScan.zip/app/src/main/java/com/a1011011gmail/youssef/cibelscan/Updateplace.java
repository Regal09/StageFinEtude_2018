package com.a1011011gmail.youssef.cibelscan;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class Updateplace extends AppCompatActivity {

    private static final String UPDATE_URL = "http://doctime.lyo.ma/CibelScan/setemp.php";
    public static final String KEY_numar = "numarticle";
    public static final String KEY_emplacement = "emplacement";

    public static EditText et5;
    EditText e,et;
    InputStream is=null;
    String result=null;
    String line=null;
    HttpURLConnection urlConnection = null;
    AlertDialog.Builder builder;
    String text, text2;
    String [] city;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updateplace);

        et5 =  (EditText) findViewById(R.id.editText5);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        e = (EditText) findViewById(R.id.editTextt);
        et = (EditText) findViewById(R.id.editText6);
        ImageButton b = (ImageButton) findViewById(R.id.search);
        ImageButton b2 = (ImageButton) findViewById(R.id.button);
        ImageButton b3 = (ImageButton) findViewById(R.id.button3);

        builder = new AlertDialog.Builder(Updateplace.this);


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Updateplace.this, Secondscan.class);
                startActivity(intent);
            }
        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Toast.makeText(getApplicationContext(), "Invalid IP Address",Toast.LENGTH_LONG).show();

                text = et5.getText().toString(); //Here i am storing the entered text in the string format in text variable

                ContentValues values = new ContentValues();
                values.put("1", text);  // This will append the entered text in the url for filter purpose


                try {

                    URL url = new URL("http://doctime.lyo.ma/CibelScan/getemp.php?string1=" + text);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("POST");
                    urlConnection.connect();
                    is = urlConnection.getInputStream();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "etape 1 waloo",Toast.LENGTH_LONG).show();
                }

                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
                    StringBuilder sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    is.close();
                    result = sb.toString();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "etape 2 walo",Toast.LENGTH_LONG).show();
                }


                try {
                    JSONArray JA = new JSONArray(result);
                    JSONObject json = null;

                    city = new String[JA.length()];


                    for (int i = 0; i < JA.length(); i++) {
                        json = JA.getJSONObject(i);
                        city[i] = json.getString("emplacement");

                    }
                    Toast.makeText(getApplicationContext(), "Data Loaded", Toast.LENGTH_LONG).show();


                    String s = result;
                    String[] arr = s.split("\"");

                    e.setText(arr[3]);
                } catch (Exception e) {

                    Toast.makeText(getApplicationContext(), "etape 3 walo",Toast.LENGTH_LONG).show();

                }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String art = et5.getText().toString().trim();
                final String emp = et.getText().toString().trim();

                if (et5.equals("") || et.equals("") ) {
                    builder.setTitle("There is a problem !!!");
                    builder.setMessage("Please fill all the fields ...");
                    displayAlert("input_error");
                }else {
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, UPDATE_URL, new Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONArray jsonArray = new JSONArray(response);
                                JSONObject jsonObject = jsonArray.getJSONObject(0);
                                String code = jsonObject.getString("code");
                                String message = jsonObject.getString("message");

                                builder.setTitle("Server response ...");
                                builder.setMessage(message);
                                displayAlert(code);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(Updateplace.this, error.toString(), Toast.LENGTH_LONG).show();
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put(KEY_numar, art);
                            params.put(KEY_emplacement, emp);


                            return params;
                        }
                    };

                    MySingleton.getmInstance(Updateplace.this).addToRequestque(stringRequest);
                }

            }
        });
    }
    public void displayAlert(final String code) {
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (code.equals("input_error")) {
                    et5.setText("");
                    et.setText("");

                } else if (code.equals("Modification_Succes")) {
                    finish();
                } else if (code.equals("Modification_échoué")) {
                    et5.setText("");
                    et.setText("");

                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
