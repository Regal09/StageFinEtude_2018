package com.a1011011gmail.youssef.cibelscan;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    int count=10;

    Handler mHandle = new Handler();
    Runnable r;

    Thread thr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r=new Runnable() {
            @Override
            public void run() {

                if(count == 0){

                    Intent i = new Intent(getBaseContext(), Accueil.class);
                    startActivity(i);

                    finish();
                }
                else{
                    Log.d("tttt", ""+count);
                    count--;
                    mHandle.postDelayed(r,1000);
                }




            }
        };



        mHandle.postDelayed(r,1000);
    }
    @Override
    protected void onDestroy() {
        mHandle.removeCallbacks(r);
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        mHandle.removeCallbacks(r);
        super.onPause();
    }

    @Override
    protected void onResume() {
        mHandle.postDelayed(r,1000);
        super.onResume();
    }

}
