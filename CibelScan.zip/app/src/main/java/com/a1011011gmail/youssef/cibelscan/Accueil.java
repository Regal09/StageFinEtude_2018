package com.a1011011gmail.youssef.cibelscan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Accueil extends AppCompatActivity {

    Button login, registre;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil);

        login = (Button)findViewById(R.id.logiin);
        registre = (Button)findViewById(R.id.signn);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(login.isPressed())
                {
                    Intent i = new Intent(Accueil.this, Login.class);
                    startActivity(i);
                }
            }
        });

        registre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(registre.isPressed())
                {
                    Intent i = new Intent(Accueil.this, Registre.class);
                    startActivity(i);
                }
            }
        });
    }
}
