package com.a1011011gmail.youssef.cibelscan;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Deletec extends AppCompatActivity {

    private static final String DELETE_URL = "http://doctime.lyo.ma/CibelScan/delete.php";


    public static final String KEY_numar = "numarticle";
    public static final String KEY_numlot = "numlot";
    public static final String KEY_numslot = "numslot";

    public static  EditText edit ;
    public static  EditText edite ;
    public static  EditText editex ;

    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deletec);

        edit = (EditText)findViewById(R.id.editart);
        edite = (EditText)findViewById(R.id.editlot);
        editex = (EditText) findViewById(R.id.editpalette);

        ImageButton scan = (ImageButton) findViewById(R.id.button);

        ImageButton sup = (ImageButton) findViewById(R.id.sup);

        builder = new AlertDialog.Builder(Deletec.this);

        sup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String numarticle = edit.getText().toString().trim();
                final String numlot = edite.getText().toString().trim();
                final String numslot = editex.getText().toString().trim();

                if (numarticle.equals("") || numlot.equals("") || numslot.equals("")) {
                    builder.setTitle("There is a problem !!!");
                    builder.setMessage("Please fill all the fields ...");
                    displayAlert("input_error");
                }else{
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, DELETE_URL, new Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONArray jsonArray = new JSONArray(response);
                                JSONObject jsonObject = jsonArray.getJSONObject(0);
                                String code = jsonObject.getString("code");
                                String message = jsonObject.getString("message");

                                builder.setTitle("Server response ...");
                                builder.setMessage(message);
                                displayAlert(code);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(Deletec.this, error.toString(), Toast.LENGTH_LONG).show();
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put(KEY_numar, numarticle);
                            params.put(KEY_numlot, numlot);
                            params.put(KEY_numslot, numslot);

                            return params;
                        }
                    };

                    MySingleton.getmInstance(Deletec.this).addToRequestque(stringRequest);
                }

            }


        });

    }

    public void displayAlert(final String code) {
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (code.equals("input_error")) {
                    edit.setText("");
                    edite.setText("");
                    editex.setText("");

                } else if (code.equals("Suppression_Succes")) {
                    finish();
                } else if (code.equals("Suppression_échoué")) {
                    edit.setText("");
                    edite.setText("");
                    editex.setText("");
                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    public void Scaan(View v){
        Intent intent = new Intent(Deletec.this, FifthScan.class);
        startActivity(intent);
    }
}
